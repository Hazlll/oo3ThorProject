package com.example.final_project;


import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.TextField;


public class PiggyBankDialogController {


    @FXML
    private TextField totalAmountTextField;


    // New method to handle the "Count" button action
    @FXML
    private void countDenominations() {
        try {
            int totalAmount = Integer.parseInt(totalAmountTextField.getText());
            calculateDenominations(totalAmount);
        } catch (NumberFormatException e) {
// If the user entered a non-numeric value, show an error message
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Invalid Input");
            errorAlert.setHeaderText(null);
            errorAlert.setContentText("Please enter a valid numeric value for the total amount.");
            errorAlert.showAndWait();
        }
    }


    private void calculateDenominations(int totalAmount) {
// Step 1: Define denominations and their values
        int[] denominations = {1000, 500, 100, 50, 20, 10, 5, 2, 1};
        int numDenominations = denominations.length;


// Step 3: Calculate the number of denominations for each type
        int[] count = new int[numDenominations]; // To store the count of each denomination
        for (int i = 0; i < numDenominations; i++) {
            count[i] = totalAmount / denominations[i];
            totalAmount = totalAmount % denominations[i];
        }


// Step 4: Display the results
        StringBuilder result = new StringBuilder();
        result.append("Number of denominations in the piggy bank:\n");
        for (int i = 0; i < numDenominations; i++) {
            result.append(denominations[i]).append(" x ").append(count[i]).append("\n");
        }


// Show the results in a dialog
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.getDialogPane().setContentText(result.toString());
        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.showAndWait();
    }
}
