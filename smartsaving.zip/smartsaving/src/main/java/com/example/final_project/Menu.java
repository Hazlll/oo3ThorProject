package com.example.final_project;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextInputDialog;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.io.IOException;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Button;
import javafx.scene.chart.XYChart;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.AnchorPane;

public class Menu extends Application {
    @FXML
    private Button backButton;
    private double maxLimit;
    private int numMonths;
    private double totalExpenses = 0;


    private Map<String, Double> expenses = new HashMap<>();
    private Scanner scanner = new Scanner(System.in);


    public void initialize() {
        System.out.println("Monthly Expense Tracker");
        System.out.println("-----------------------");
    }


    public static void main(String[] args) {
        launch(args);
    }


    public void setMaxLimit(double maxLimit) {
        this.maxLimit = maxLimit;
    }


    public void setNumMonths(int numMonths) {
        this.numMonths = numMonths;
    }


    @Override
    public void start(Stage primaryStage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Menu.class.getResource("menu.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);


        primaryStage.setTitle("SmartSavings");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    @FXML
    private void TotalMoney() {
        TextInputDialog principalDialog = new TextInputDialog();
        principalDialog.setTitle("Principal");
        principalDialog.setHeaderText("Enter the principal amount:");
        principalDialog.setContentText("Principal:");
        String principalInput = principalDialog.showAndWait().orElse(null);


        if (principalInput == null) {
            // User canceled the dialog, so return early
            return;
        }


        double principal;
        try {
            principal = Double.parseDouble(principalInput);
        } catch (NumberFormatException e) {
            // Invalid input for principal, show an error alert and return early
            showInputErrorAlert("Invalid input for principal.");
            return;
        }


        TextInputDialog interestRateDialog = new TextInputDialog();
        interestRateDialog.setTitle("Interest Rate");
        interestRateDialog.setHeaderText("Enter the interest rate (in %):");
        interestRateDialog.setContentText("Interest Rate:");
        String interestRateInput = interestRateDialog.showAndWait().orElse(null);


        if (interestRateInput == null) {
            // User canceled the dialog, so return early
            return;
        }


        double interestRate;
        try {
            interestRate = Double.parseDouble(interestRateInput);
        } catch (NumberFormatException e) {
            // Invalid input for interest rate, show an error alert and return early
            showInputErrorAlert("Invalid input for interest rate.");
            return;
        }


        TextInputDialog timePeriodDialog = new TextInputDialog();
        timePeriodDialog.setTitle("Time Period");
        timePeriodDialog.setHeaderText("Enter the time period (in months):");
        timePeriodDialog.setContentText("Time Period:");
        String timePeriodInput = timePeriodDialog.showAndWait().orElse(null);


        if (timePeriodInput == null) {
            // User canceled the dialog, so return early
            return;
        }


        int timePeriod;
        try {
            timePeriod = Integer.parseInt(timePeriodInput);
        } catch (NumberFormatException e) {
            // Invalid input for time period, show an error alert and return early
            showInputErrorAlert("Invalid input for time period.");
            return;
        }


        // Perform the calculation
        double totalSavings = calculateTotalSavings(principal, interestRate, timePeriod);


        // Display the result
        Alert resultAlert = new Alert(AlertType.INFORMATION);
        resultAlert.setTitle("Result");
        resultAlert.setHeaderText("Total of Money Earned");
        resultAlert.setContentText("Total Money Earned: $" + totalSavings);
        resultAlert.showAndWait();
    }


    // Calculate the total money earned using the formula A = P * (1 + r/n)^(n*t)
    private double calculateTotalSavings(double principal, double interestRate, int timePeriod) {
        int n = 12; // Assuming the interest is compounded monthly
        double r = interestRate / 100; // Convert percentage to decimal
        return principal * Math.pow(1 + r / n, n * timePeriod);
    }


    @FXML
    private void handleExpenseButton() {
        addExpense();
        displayExpensesSummary(); // Call the displayExpensesSummary() method after adding expenses
    }


    private void addExpense() {
        while (true) {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Add Expense");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the expense type (or 'quit' to exit):");
            Optional<String> result = dialog.showAndWait();


            if (!result.isPresent()) {
                // User canceled the dialog, so return early
                return;
            }


            String expenseType = result.get().trim();
            if (expenseType.equalsIgnoreCase("quit")) {
                break; // Exit the loop when the user enters "quit"
            }


            dialog = new TextInputDialog();
            dialog.setTitle("Add Expense");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the expense amount:");
            result = dialog.showAndWait();


            if (!result.isPresent()) {
                // User canceled the dialog, so return early
                return;
            }


            double expenseAmount;
            while (true) {
                try {
                    expenseAmount = Double.parseDouble(result.get());
                    break; // If parsing is successful, exit the loop
                } catch (NumberFormatException e) {
                    showErrorAlert("Invalid expense amount! Please enter a valid number.");
                    result = dialog.showAndWait(); // Ask the user to input again
                    if (!result.isPresent()) {
                        // User canceled the dialog, so return early
                        return;
                    }
                }
            }


            if (expenses.containsKey(expenseType)) {
                double totalExpense = expenses.get(expenseType) + expenseAmount;
                expenses.put(expenseType, totalExpense);
            } else {
                expenses.put(expenseType, expenseAmount);
            }
        }
    } // Closing brace for addExpense() method was missing


    private void displayExpensesSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("\nMonthly Expenses Summary");
        summary.append("\n-----------------------");


        double totalExpenses = 0.0;
        for (Map.Entry<String, Double> entry : expenses.entrySet()) {
            String expenseType = entry.getKey();
            double expenseAmount = entry.getValue();


            summary.append("\n").append(expenseType).append(": $").append(expenseAmount);
            totalExpenses += expenseAmount;
        }


        summary.append("\n\nTotal Monthly Expenses: $").append(totalExpenses);


        Alert summaryAlert = new Alert(AlertType.INFORMATION);
        summaryAlert.setTitle("Expenses Summary");
        summaryAlert.setHeaderText(null);
        summaryAlert.setContentText(summary.toString());
        summaryAlert.showAndWait();
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleDisplayMonthlyReport() {
        // Set the maxLimit and numMonths values before displaying the report
        setMaxLimitFromInput();
        setNumMonthsFromInput();

        int month = 1;
        double totalExpenses = 0.0;
        StringBuilder reportContent = new StringBuilder();
        boolean limitExceeded = false; // Track if limit was exceeded for any month

        while (month <= numMonths) {
            double monthlyExpense = getMonthlyExpense();
            totalExpenses += monthlyExpense;
            double averageExpense = totalExpenses / month;

            // Check if the user has exceeded or reached the desired maxLimit for this month
            if (monthlyExpense >= maxLimit && !limitExceeded) {
                limitExceeded = true; // Set the flag to true to indicate limit exceeded
            }

            // Append the monthly expenses information to the reportContent
            reportContent.append("Month ").append(month).append(":")
                    .append("\nMonthly Expense: ").append(monthlyExpense)
                    .append("\nAverage Expense: ").append(averageExpense)
                    .append("\nMaximum Limit: ").append(maxLimit).append("\n\n");

            month++;
        }

        // Display warning alert if the limit was exceeded for any month
        if (limitExceeded) {
            Alert warningAlert = new Alert(AlertType.WARNING);
            warningAlert.setTitle("Warning!");
            warningAlert.setHeaderText(null);
            warningAlert.setContentText("You have exceeded the maximum limit for one or more months. Please manage your money wisely.");
            warningAlert.showAndWait();
        }

        // After the loop finishes, display the monthly report in one alert with all the content
        displayMonthlyReport(reportContent.toString());
    }


    private void displayMonthlyReport(String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Monthly Expenses Report");
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.show(); // Use show() instead of showAndWait() to allow the loop to continue
    }


    private void setMaxLimitFromInput() {
        while (true) {
            TextInputDialog maxLimitDialog = new TextInputDialog();
            maxLimitDialog.setTitle("Set Maximum Limit");
            maxLimitDialog.setHeaderText("Enter the maximum limit:");
            maxLimitDialog.setContentText("Maximum Limit:");
            String maxLimitInput = maxLimitDialog.showAndWait().orElse(null);

            if (maxLimitInput == null) {
                // User canceled the dialog, so return early
                return;
            }

            try {
                double maxLimit = Double.parseDouble(maxLimitInput);
                setMaxLimit(maxLimit);
                break; // Break out of the loop if the input is valid
            } catch (NumberFormatException e) {
                showInputErrorAlert("Invalid input for maximum limit.");
            }
        }
    }

    private void setNumMonthsFromInput() {
        while (true) {
            TextInputDialog numMonthsDialog = new TextInputDialog();
            numMonthsDialog.setTitle("Set Number of Months");
            numMonthsDialog.setHeaderText("Enter the number of months:");
            numMonthsDialog.setContentText("Number of Months:");
            String numMonthsInput = numMonthsDialog.showAndWait().orElse(null);

            if (numMonthsInput == null) {
                // User canceled the dialog, so return early
                return;
            }

            try {
                int numMonths = Integer.parseInt(numMonthsInput);
                setNumMonths(numMonths);
                break; // Break out of the loop if the input is valid
            } catch (NumberFormatException e) {
                showInputErrorAlert("Invalid input for number of months.");
            }
        }
    }

    private double getMonthlyExpense() {
        while (true) {
            TextInputDialog expenseDialog = new TextInputDialog();
            expenseDialog.setTitle("Monthly Expense");
            expenseDialog.setHeaderText(null);
            expenseDialog.setContentText("Enter your expenses for this month:");
            Optional<String> result = expenseDialog.showAndWait();

            if (result.isPresent()) {
                try {
                    return Double.parseDouble(result.get());
                } catch (NumberFormatException e) {
                    showInputErrorAlert("Invalid input for monthly expense.");
                }
            } else {
                // User canceled the dialog, so return 0.0
                return 0.0;
            }
        }
    }

    @FXML
    private void handleGraphButton() {
        // Create a dialog to get the number of months
        TextInputDialog monthsDialog = new TextInputDialog();
        monthsDialog.setTitle("Input");
        monthsDialog.setHeaderText("Enter the number of months for savings calculation:");

        // Show the dialog and get the number of months
        monthsDialog.showAndWait().ifPresent(months -> {
            try {
                int numMonths = Integer.parseInt(months);

                // Create the BarChart data series
                XYChart.Series<String, Number> dataSeries = new XYChart.Series<>();
                dataSeries.setName("Savings Growth");


                for (int i = 1; i <= numMonths; i++) {
                    double savings = 0; // Reset savings for the current month

                    // Get monthly income and expenses
                    double monthlyIncome = getMonthlyValue("income", i);
                    double monthlyExpenses = getMonthlyValue("expenses", i);

                    // Calculate savings for the current month
                    double monthlySavings = monthlyIncome - monthlyExpenses;
                    savings += monthlySavings;

                    // Add data to the BarChart series
                    dataSeries.getData().add(new XYChart.Data<>(String.format("Month %d", i), savings));
                }

                try {
                    FXMLLoader graphLoader = new FXMLLoader(getClass().getResource("Graph.fxml"));
                    Parent graphRoot = graphLoader.load();

                    // Update the chart data using the GraphController
                    GraphController graphController = graphLoader.getController();
                    graphController.updateChartData(dataSeries);

                    // Show the graph in a new dialog
                    Stage graphStage = new Stage();
                    graphStage.setTitle("Savings Growth Over Time");
                    graphStage.setScene(new Scene(graphRoot));
                    graphStage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (NumberFormatException e) {
                // Show an error dialog for non-integer input
                Alert errorAlert = new Alert(AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText("Invalid Input");
                errorAlert.setContentText("Please enter a valid integer value for the number of months.");
                errorAlert.showAndWait();
            }
        });
    }

    private double getMonthlyValue(String type, int monthNumber) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Input");
        dialog.setHeaderText(String.format("Enter the monthly %s for month %d:", type, monthNumber));
        return dialog.showAndWait()
                .map(Double::parseDouble)
                .orElse(0.0); // Default value if the user cancels the dialog or enters invalid input
    }

    @FXML
    private void PiggyBank() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PiggyBank.fxml"));
            AnchorPane root = fxmlLoader.load();
            PiggyBankDialogController controller = fxmlLoader.getController();
            // If you need to pass any data to the dialog controller, you can do it here

            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.getDialogPane().setContent(root);
            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
            dialog.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    public void exit() {
        Alert thankYouAlert = new Alert(Alert.AlertType.INFORMATION);
        thankYouAlert.setTitle("Thank You");
        thankYouAlert.setHeaderText(null);
        thankYouAlert.setContentText("Thank you for using the program!\n\n The program will be exiting after 2 seconds when you press OK.");
        thankYouAlert.showAndWait();


        // Create a PauseTransition to delay the program's exit for 2 seconds
        PauseTransition delay = new PauseTransition(Duration.seconds(2));
        delay.setOnFinished(event -> Platform.exit()); // Exit the application after the delay


        delay.play();
    }
    // Helper method to show an input error alert
    private void showInputErrorAlert(String message) {
        Alert errorAlert = new Alert(AlertType.ERROR);
        errorAlert.setTitle("Input Error");
        errorAlert.setHeaderText(null);
        errorAlert.setContentText(message);
        errorAlert.showAndWait();
    }
}

