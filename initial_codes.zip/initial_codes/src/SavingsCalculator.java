public class SavingsCalculator {
    private double initialDeposit;
    private double monthlyPayment;
    private double interestRate;

    public SavingsCalculator(double initialDeposit, double monthlyPayment, double interestRate) {
        this.initialDeposit = initialDeposit;
        this.monthlyPayment = monthlyPayment;
        this.interestRate = interestRate;
    }

    public double calculateTotalSavings(int numberOfMonths) {
        double totalSavings = initialDeposit;
        for (int i = 1; i <= numberOfMonths; i++) {
            totalSavings += monthlyPayment;
            totalSavings *= (1 + interestRate);
        }
        return totalSavings;
    }
}
