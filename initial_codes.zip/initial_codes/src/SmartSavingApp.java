import java.util.*;

public class SmartSavingApp {
    private Scanner scanner;
    private List<Expense> expenses;
    private double maximumSpendingLimit;
    private Map<Integer, Double> savingsGraph;

    public SmartSavingApp() {
        scanner = new Scanner(System.in);
        expenses = new ArrayList<>();
        maximumSpendingLimit = 0;
        savingsGraph = new HashMap<>();
    }

    public void start() {
        System.out.println("Welcome to SmartSaving App!");
        System.out.println("Select an option:");
        System.out.println("1. Calculate total savings");
        System.out.println("2. Add an expense");
        System.out.println("3. Set maximum spending limit");
        System.out.println("4. Generate savings graph");
        System.out.println("0. Exit");

        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                calculateTotalSavings();
                break;
            case 2:
                addExpense();
                break;
            case 3:
                setMaximumSpendingLimit();
                break;
            case 4:
                generateSavingsGraph();
                break;
            case 0:
                System.out.println("Thank you for using SmartSaving App!");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
                start();
        }
    }

    private void calculateTotalSavings() {
        System.out.println("Enter initial deposit:");
        double initialDeposit = scanner.nextDouble();

        System.out.println("Enter monthly payment:");
        double monthlyPayment = scanner.nextDouble();

        System.out.println("Enter interest rate:");
        double interestRate = scanner.nextDouble();

        SavingsCalculator calculator = new SavingsCalculator(initialDeposit, monthlyPayment, interestRate);

        System.out.println("Enter number of months:");
        int numberOfMonths = scanner.nextInt();

        double totalSavings = calculator.calculateTotalSavings(numberOfMonths);
        System.out.println("Total savings after " + numberOfMonths + " months: " + totalSavings);

        start();
    }

    private void addExpense() {
        System.out.println("Enter expense category:");
        String category = scanner.next();

        System.out.println("Enter expense amount:");
        double amount = scanner.nextDouble();

        expenses.add(new Expense(category, amount));

        start();
    }

    private void setMaximumSpendingLimit() {
        System.out.println("Enter maximum spending limit:");
        maximumSpendingLimit = scanner.nextDouble();

        start();
    }

    private void generateSavingsGraph() {
        System.out.println("Enter number of data points for the graph:");
        int numberOfDataPoints = scanner.nextInt();

        for (int i = 1; i <= numberOfDataPoints; i++) {
            System.out.println("Enter month " + i + " savings:");
            double savings = scanner.nextDouble();
            savingsGraph.put(i, savings);
        }

        System.out.println("Savings graph:");
        for (Map.Entry<Integer, Double> entry : savingsGraph.entrySet()) {
            System.out.println("Month " + entry.getKey() + ": " + entry.getValue());
        }

        start();
    }
}
