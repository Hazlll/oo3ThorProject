public class Main {
    public static void main(String[] args) {
        SmartSavingApp app = new SmartSavingApp();
        app.start();
    }
}
